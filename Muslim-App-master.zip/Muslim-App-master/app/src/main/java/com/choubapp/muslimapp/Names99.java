package com.choubapp.muslimapp;

public class Names99 {
    private String mText;
    public Names99(String text) {
        mText = text;
    }
    public String getText() {
        return mText;
    }
}
