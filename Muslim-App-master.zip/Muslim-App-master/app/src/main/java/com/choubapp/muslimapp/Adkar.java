package com.choubapp.muslimapp;

public class Adkar {
    private String mDouaa;
    private String mTimes;

    public Adkar(String text1, String text2) {
        mDouaa = text1;
        mTimes = text2;
    }

    public String getDouaa() {
        return mDouaa;
    }

    public String getTimes() {
        return mTimes;
    }
}
